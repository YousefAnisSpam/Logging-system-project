import requests
import time
import sys
import socket
import datetime
import logging
import os
import json

# Windows specific imports
try:
    import win32evtlog # Requires pywin32 package
    import win32evtlogutil
    import pywintypes
except ImportError:
    print("ERROR: The 'pywin32' package is required for this script.")
    print("Please install it by running: pip install pywin32")
    sys.exit(1)

# --- Configuration ---
SERVER_URL = "http://localhost:5000/log"
LOCAL_LOG_FILE = "logs/client_eventlog_fallback.log"  # Added directory path

try:
    CLIENT_ID = f"EventLogClient_{socket.gethostname()}"
except Exception:
    CLIENT_ID = "EventLogClient_UnknownHost"

LOGS_TO_MONITOR = ['Application', 'System']
EVENT_TYPE_MAP = {
    win32evtlog.EVENTLOG_INFORMATION_TYPE: "INFO",
    win32evtlog.EVENTLOG_WARNING_TYPE: "WARNING",
    win32evtlog.EVENTLOG_ERROR_TYPE: "ERROR",
    win32evtlog.EVENTLOG_AUDIT_SUCCESS: "AUDIT_SUCCESS",
    win32evtlog.EVENTLOG_AUDIT_FAILURE: "AUDIT_FAILURE",
}
LEVELS_TO_FORWARD = {"INFO", "WARNING", "ERROR", "AUDIT_SUCCESS", "AUDIT_FAILURE"}

POLL_INTERVAL_SECONDS = 1
SEND_DELAY_SECONDS = 1
REQUEST_TIMEOUT_SECONDS = 10
MAX_EVENTS_PER_CYCLE = 1000  # Limit events processed per cycle
MAX_RETRIES = 3  # Number of retries for sending logs
RETRY_DELAY_SECONDS = 1  # Delay between retries

last_record_numbers = {}


# --- Setup Logging ---
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')
script_logger = logging.getLogger("EventLogClient")

# Create directory for local log file if it has a directory component
log_dir = os.path.dirname(LOCAL_LOG_FILE)
if log_dir:
    os.makedirs(log_dir, exist_ok=True)
# ---

def save_log_locally(log_data):
    """Saves a log to a local file if server is unreachable."""
    try:
        with open(LOCAL_LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_data) + '\n')
        script_logger.debug(f"Saved log to {LOCAL_LOG_FILE}: {log_data['message'][:100]}...")
    except Exception as e:
        script_logger.error(f"Failed to save log to {LOCAL_LOG_FILE}: {e}")

def send_log_to_server(level, message_content):
    """Sends a structured log message to the central server with retries."""
    log_data = {
        "level": level,
        "message": message_content,
        "client_id": CLIENT_ID
    }
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.post(SERVER_URL, json=log_data, timeout=REQUEST_TIMEOUT_SECONDS)
            response.raise_for_status()
            script_logger.debug(f"Successfully sent {level} log: {message_content[:100]}...")
            return True
        except requests.exceptions.ConnectionError:
            script_logger.error(f"CONNECTION ERROR (Attempt {attempt + 1}/{MAX_RETRIES}): Could not connect to {SERVER_URL}.")
            script_logger.error("    TROUBLESHOOTING:")
            script_logger.error(f"    1. Verify server is running: On server, run 'netstat -an | findstr 5000' (Windows) or 'netstat -tuln | grep 5000' (Linux).")
            script_logger.error(f"    2. Check server IP: On server, run 'ipconfig' (Windows) or 'ip addr' (Linux) to confirm 192.168.1.3.")
            script_logger.error(f"    3. Test connectivity: From this machine, run 'ping 192.168.1.3' and 'curl {SERVER_URL} -X POST -H \"Content-Type: application/json\" -d \"{{\\\"level\\\": \\\"INFO\\\", \\\"message\\\": \\\"Test\\\", \\\"client_id\\\": \\\"test\\\"}}\"'.")
            script_logger.error(f"    4. Check firewall: On server, ensure port 5000 is open (e.g., 'netsh advfirewall firewall add rule name=\"Flask 5000\" dir=in action=allow protocol=TCP localport=5000' on Windows).")
            if attempt < MAX_RETRIES - 1:
                script_logger.info(f"Retrying in {RETRY_DELAY_SECONDS} seconds...")
                time.sleep(RETRY_DELAY_SECONDS)
        except requests.exceptions.Timeout:
            script_logger.error(f"TIMEOUT ERROR (Attempt {attempt + 1}/{MAX_RETRIES}): Request timed out sending log to {SERVER_URL}.")
        except requests.exceptions.HTTPError as http_err:
            script_logger.error(f"HTTP ERROR (Attempt {attempt + 1}/{MAX_RETRIES}): {http_err.response.status_code} {http_err.response.reason}")
            try:
                script_logger.error(f"    Server response: {http_err.response.text[:500]}")
            except Exception:
                script_logger.error("    Server response could not be parsed.")
        except requests.exceptions.RequestException as e:
            script_logger.error(f"REQUEST EXCEPTION (Attempt {attempt + 1}/{MAX_RETRIES}): {e}")
    script_logger.error(f"Failed to send log after {MAX_RETRIES} attempts. Saving to {LOCAL_LOG_FILE}.")
    save_log_locally(log_data)
    return False

def get_event_details(event_obj, log_name_str):
    """Extracts and formats details from a Windows event object."""
    event_level_windows = event_obj.EventType
    mapped_level = EVENT_TYPE_MAP.get(event_level_windows, "UNKNOWN")
    message_str = "Error formatting message."
    try:
        formatted_msg_content = win32evtlogutil.SafeFormatMessage(event_obj, log_name_str)
        if formatted_msg_content is None:
            inserts = event_obj.StringInserts
            if inserts:
                message_str = f"Message could not be formatted (DLL missing?). Data: {', '.join(inserts if inserts else [])}"
            else:
                message_str = "Message could not be formatted (DLL missing?) and no data inserts found."
        else:
            message_str = formatted_msg_content.replace('\x00', '').strip()
    except pywintypes.error as e_fmt:
        message_str = f"Could not format message (Win32 Error: {e_fmt.winerror} - {e_fmt.strerror}) - Data: {event_obj.StringInserts}"
    except Exception as e_fmt_other:
        message_str = f"Unexpected error formatting message: {e_fmt_other}"

    source_name_str = event_obj.SourceName or "N/A"
    event_id_val = event_obj.EventID & 0xFFFF
    computer_name_str = event_obj.ComputerName or "N/A"
    try:
        time_generated_str = event_obj.TimeGenerated.strftime('%Y-%m-%d %H:%M:%S') if event_obj.TimeGenerated else "N/A"
    except ValueError:
        time_generated_str = "Invalid Time"

    full_formatted_message = (
        f"WinEventLog | Log: {log_name_str} | Time: {time_generated_str} | Source: {source_name_str} | "
        f"EventID: {event_id_val} | Level: {mapped_level} | Computer: {computer_name_str} | Message: {message_str}"
    )
    return mapped_level, full_formatted_message

def get_start_record_number(log_name_str):
    """Gets the oldest record number to start reading from."""
    handle = None
    try:
        handle = win32evtlog.OpenEventLog(None, log_name_str)
        total_records = win32evtlog.GetNumberOfEventLogRecords(handle)
        if total_records == 0:
            script_logger.info(f"Log '{log_name_str}' is empty or inaccessible. Starting from record 0.")
            return 0
        oldest_rec_num = win32evtlog.GetOldestEventLogRecord(handle)
        latest_rec_num = oldest_rec_num + total_records - 1
        script_logger.info(f"Log '{log_name_str}' state: Total={total_records}, OldestRec={oldest_rec_num}, LatestRec={latest_rec_num}.")
        return oldest_rec_num
    except pywintypes.error as e_getlatest:
        if e_getlatest.winerror == 5:
            script_logger.error(f"ACCESS DENIED getting records for '{log_name_str}'. Try running script as Administrator.")
        else:
            script_logger.error(f"Win32 error {e_getlatest.winerror} getting records for '{log_name_str}': {e_getlatest.strerror}")
        return 0
    except Exception as e_getlatest_other:
        script_logger.error(f"Unexpected error getting records for '{log_name_str}': {e_getlatest_other}")
        return 0
    finally:
        if handle:
            win32evtlog.CloseEventLog(handle)

def read_events_from_log(log_name_str, start_rec_num):
    """Reads events from a specific log starting from start_rec_num."""
    handle = None
    events_list = []
    current_max_rec_num_seen = start_rec_num
    try:
        handle = win32evtlog.OpenEventLog(None, log_name_str)
        flags = win32evtlog.EVENTLOG_FORWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
        
        total_records_now = win32evtlog.GetNumberOfEventLogRecords(handle)
        if total_records_now == 0:
            if start_rec_num != 0:
                script_logger.warning(f"Log '{log_name_str}' became empty. Resetting marker to 0.")
            return [], 0

        oldest_rec_now = win32evtlog.GetOldestEventLogRecord(handle)
        current_actual_latest_rec = oldest_rec_now + total_records_now - 1

        if start_rec_num < oldest_rec_now:
            script_logger.warning(f"Log '{log_name_str}' oldest record is now {oldest_rec_now}. Starting from there.")
            start_rec_num = oldest_rec_now
            current_max_rec_num_seen = start_rec_num

        events_processed_this_read = 0

        while events_processed_this_read < MAX_EVENTS_PER_CYCLE:
            events_chunk = win32evtlog.ReadEventLog(handle, flags, start_rec_num, 100)
            if not events_chunk:
                break
            for event_obj in events_chunk:
                events_processed_this_read += 1
                record_num = event_obj.RecordNumber
                current_max_rec_num_seen = max(current_max_rec_num_seen, record_num)
                events_list.append(event_obj)
                if record_num >= current_actual_latest_rec:
                    break
            start_rec_num = current_max_rec_num_seen + 1

        if events_processed_this_read >= MAX_EVENTS_PER_CYCLE:
            script_logger.warning(f"Reached max {MAX_EVENTS_PER_CYCLE} events from '{log_name_str}'. Will continue from record {current_max_rec_num_seen + 1} next cycle.")

        return events_list, current_max_rec_num_seen
    except pywintypes.error as e_read:
        if e_read.winerror == 5:
            script_logger.error(f"ACCESS DENIED reading log '{log_name_str}'. Try running as Administrator.")
        elif e_read.winerror == 1722:
            script_logger.error(f"RPC Server unavailable (Event Log service might be stopped?) for '{log_name_str}'.")
        else:
            script_logger.error(f"Win32 error {e_read.winerror} reading '{log_name_str}': {e_read.strerror}")
        return [], start_rec_num
    except Exception as e_read_other:
        script_logger.exception(f"Unexpected error reading log '{log_name_str}': {e_read_other}")
        return [], start_rec_num
    finally:
        if handle:
            win32evtlog.CloseEventLog(handle)

if __name__ == "__main__":
    script_logger.info(f"--- Starting Windows Event Log Client v1.4 ---")
    script_logger.info(f"Client ID: {CLIENT_ID}")
    script_logger.info(f"Target Server URL: {SERVER_URL}")
    script_logger.info(f"Monitoring Logs: {', '.join(LOGS_TO_MONITOR)}")
    script_logger.info(f"Forwarding Levels: {', '.join(LEVELS_TO_FORWARD)}")
    script_logger.info(f"Polling Interval: {POLL_INTERVAL_SECONDS}s")
    script_logger.info(f"Local Log File: {LOCAL_LOG_FILE}")

    for log_name_to_init in LOGS_TO_MONITOR:
        last_record_numbers[log_name_to_init] = get_start_record_number(log_name_to_init)
        script_logger.info(f" -> Initialized '{log_name_to_init}', starting from RecordNumber {last_record_numbers[log_name_to_init]}")

    script_logger.info("Initialization complete. Starting main event loop (Press Ctrl+C to stop)...")

    try:
        while True:
            script_logger.debug(f"--- Poll Cycle ---")
            found_any_this_cycle = False
            for log_name in LOGS_TO_MONITOR:
                start_rec_num = last_record_numbers.get(log_name, 0)
                script_logger.debug(f"Checking '{log_name}' for events from RecordNumber {start_rec_num}")
                
                event_objects, highest_rec_num_seen = read_events_from_log(log_name, start_rec_num)

                if event_objects:
                    found_any_this_cycle = True
                    script_logger.info(f"Found {len(event_objects)} event(s) in '{log_name}', attempting to send...")
                    for event_obj in event_objects:
                        event_level, event_message_str = get_event_details(event_obj, log_name)
                        if event_level in LEVELS_TO_FORWARD:
                            script_logger.debug(f"  Sending: Lvl={event_level}, Rec={event_obj.RecordNumber}, ID={event_obj.EventID & 0xFFFF} from '{log_name}'")
                            send_log_to_server(event_level, event_message_str)
                            if SEND_DELAY_SECONDS > 0:
                                time.sleep(SEND_DELAY_SECONDS)
                        else:
                            script_logger.debug(f"  Skipping (level filter): Lvl={event_level}, Rec={event_obj.RecordNumber} from '{log_name}'")
                
                # Update marker for next cycle
                if highest_rec_num_seen > start_rec_num:
                    script_logger.debug(f"Updating marker for '{log_name}' to {highest_rec_num_seen} (was {start_rec_num})")
                    last_record_numbers[log_name] = highest_rec_num_seen
                elif highest_rec_num_seen < start_rec_num:
                    script_logger.info(f"Marker for '{log_name}' updated to {highest_rec_num_seen} due to log wrap/clear.")
                    last_record_numbers[log_name] = highest_rec_num_seen

            if not found_any_this_cycle:
                script_logger.debug("No relevant events in any monitored logs this cycle.")
            
            script_logger.debug(f"Sleeping for {POLL_INTERVAL_SECONDS} seconds...")
            time.sleep(POLL_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        script_logger.info("Shutdown requested (Ctrl+C).")
        send_log_to_server("INFO", f"{CLIENT_ID} (EventLogClient) shutting down.")
    except Exception as e_main:
        script_logger.critical("CRITICAL UNEXPECTED ERROR in main loop!", exc_info=True)
        send_log_to_server("ERROR", f"{CLIENT_ID} (EventLogClient) CRITICAL ERROR: {e_main}")
    finally:
        script_logger.info("Client stopped.")
        sys.exit(0)