import requests
import time
import random
import sys

SERVER_URL = "http://localhost:5000/log"

CLIENT_ID = f"Client_{random.randint(1000, 9999)}" # Simple way to identify different clients

def send_log(level, message):
    """Sends a log message to the central server."""
    log_data = {
        "level": level,
        "message": message,
        "client_id": CLIENT_ID
    }
    try:
        response = requests.post(SERVER_URL, json=log_data, timeout=5) # 5 second timeout
        response.raise_for_status() # Raise an exception for bad status codes (4xx or 5xx)
        print(f"[{CLIENT_ID}] Successfully sent {level} log: {message}")
        # print(f" -> Server response: {response.json()}")
    except requests.exceptions.ConnectionError:
        print(f"[{CLIENT_ID}] Error: Could not connect to the logging server at {SERVER_URL}.")
    except requests.exceptions.Timeout:
        print(f"[{CLIENT_ID}] Error: Request timed out while sending log to {SERVER_URL}.")
    except requests.exceptions.RequestException as e:
        print(f"[{CLIENT_ID}] Error sending log: {e}")
        # Print server error details if available
        try:
            print(f" -> Server error response: {e.response.json()}")
        except: # Handle cases where response might not be JSON or doesn't exist
            pass

# --- Example Usage ---
if __name__ == "__main__":
    print(f"Starting log client: {CLIENT_ID}")
    print(f"Sending logs to: {SERVER_URL}")

    log_levels = ["INFO", "WARNING", "ERROR"]
    messages = [
        "User logged in successfully.",
        "Configuration file loaded.",
        "Disk space is low.",
        "Failed to connect to database.",
        "Data processing complete.",
        "Received invalid input parameter.",
        "External API call timed out.",
        "Cache cleared.",
        "Security vulnerability detected!",
        "Application started."
    ]

    # Send a few initial logs
    send_log("INFO", "Client application starting up.")
    time.sleep(1)
    send_log("WARNING", "Network connection seems slow.")
    time.sleep(2)

    # Send logs periodically
    try:
        while True:
            level = random.choice(log_levels)
            message = random.choice(messages)
            send_log(level, message)
            sleep_time = random.uniform(1, 2) # Wait 1 to 5 seconds
            print(f"[{CLIENT_ID}] Sleeping for {sleep_time:.2f} seconds...")
            time.sleep(sleep_time)
    except KeyboardInterrupt:
        print(f"\n[{CLIENT_ID}] Client shutdown requested.")
        send_log("INFO", "Client application shutting down.")
        sys.exit(0)