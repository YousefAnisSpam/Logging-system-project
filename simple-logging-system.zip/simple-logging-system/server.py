import os
import datetime
import threading
import json
import uuid
import re
import queue
from flask import Flask, request, jsonify, render_template, abort, g, url_for, redirect, Response, stream_with_context, send_file
import io

app = Flask(__name__)

# --- Configuration ---
LOG_FILE = "app.log"
STATE_FILE = "log_state.json"
VALID_LOG_LEVELS = {"INFO", "WARNING", "ERROR", "UNKNOWN"}

# Locks for file access
log_lock = threading.Lock()
state_lock = threading.Lock()


log_stream_queue = queue.Queue(maxsize=200)

LOG_LINE_REGEX = re.compile(
    r"^(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\s+-\s+"
    r"\[(?P<level>\w+)\]\s+-\s+"
    r"\[(?P<client_id>[^\]]+)\]\s+-\s+"
    r"\[ID:(?P<uuid>[a-f0-9\-]+)\]\s+-\s+"
    r"(?P<message>.*)$"
)

# Ensure log/state files exist
if not os.path.exists(STATE_FILE):
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump({}, f)
    except IOError as e:
        print(f"Error creating state file '{STATE_FILE}': {e}")

# --- State Management Functions ---
def load_state():
    with state_lock:
        try:
            with open(STATE_FILE, 'r', encoding='utf-8') as f:
                content = f.read()
                if not content: return {}
                return json.loads(content)
        except FileNotFoundError:
            print(f"Warning: State file '{STATE_FILE}' not found. Starting with empty state.")
            return {}
        except json.JSONDecodeError:
            print(f"Warning: State file '{STATE_FILE}' contains invalid JSON. Starting with empty state.")
            return {}
        except Exception as e:
            print(f"Error loading state file '{STATE_FILE}': {e}")
            return {}

def save_state(state_data):
    with state_lock:
        try:
            with open(STATE_FILE, 'w', encoding='utf-8') as f:
                json.dump(state_data, f, indent=2)
        except IOError as e:
            print(f"Error saving state file '{STATE_FILE}': {e}")

# --- Log Reading Function ---
def read_logs_with_state(filter_deleted=True, filter_tickets=False):
    logs = []
    state_data = load_state()
    processed_uuids_for_current_read = set()
    with log_lock:
        try:
            if os.path.exists(LOG_FILE):
                with open(LOG_FILE, 'r', encoding='utf-8') as f:
                    for line_num, line in enumerate(f):
                        line = line.strip()
                        if not line: continue
                        match = LOG_LINE_REGEX.match(line)
                        if match:
                            log_data = match.groupdict()
                            log_uuid = log_data['uuid']
                            if log_uuid in processed_uuids_for_current_read:
                                continue
                            processed_uuids_for_current_read.add(log_uuid)
                            log_state = state_data.get(log_uuid, {})
                            is_deleted = log_state.get('deleted', False)
                            if filter_deleted and is_deleted:
                                continue
                            is_ticket = log_state.get('ticketed', False)
                            if filter_tickets and not is_ticket:
                                continue
                            try:
                                timestamp_dt = datetime.datetime.strptime(log_data['timestamp'], '%Y-%m-%d %H:%M:%S,%f')
                            except ValueError:
                                timestamp_dt = None
                            log_entry = {
                                'uuid': log_uuid,
                                'timestamp_str': log_data['timestamp'],
                                'timestamp_dt': timestamp_dt,
                                'log_level': log_data.get('level', 'UNKNOWN').upper(),
                                'client_id': log_data.get('client_id', 'UNKNOWN'),
                                'message': log_data.get('message', ''),
                                'is_pinned': log_state.get('pinned', False),
                                'is_ticket': is_ticket,
                                'line_num': line_num
                            }
                            logs.append(log_entry)
        except FileNotFoundError:
            print(f"Log file '{LOG_FILE}' disappeared during read.")
            return []
        except Exception as e:
            print(f"Error reading or parsing log file '{LOG_FILE}': {e}")
            return []
    try:
        logs.sort(key=lambda x: x.get('timestamp_dt') or datetime.datetime.min, reverse=True)
    except Exception as e:
        print(f"Warning: Could not sort logs by timestamp: {e}")
    return logs

# --- Routes ---
@app.route('/')
def index():
    return redirect(url_for('view_logs'))

@app.route('/log', methods=['POST'])
def receive_log():
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400
    data = request.get_json()
    level = data.get('level', 'UNKNOWN').upper()
    message = data.get('message')
    client_id = data.get('client_id', 'UNKNOWN_CLIENT')
    if not message:
        return jsonify({"error": "Missing 'message' in JSON payload"}), 400
    if level not in VALID_LOG_LEVELS:
        level = "UNKNOWN"
    timestamp_str = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S,%f')[:-3]
    log_uuid = str(uuid.uuid4())
    log_line_to_file = f"{timestamp_str} - [{level}] - [{client_id}] - [ID:{log_uuid}] - {message}\n"
    try:
        with log_lock:
            log_dir = os.path.dirname(LOG_FILE)
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir)
            with open(LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(log_line_to_file)
        log_data_for_stream = {
            'uuid': log_uuid,
            'timestamp_str': timestamp_str,
            'log_level': level,
            'client_id': client_id,
            'message': message,
            'is_pinned': False,
            'is_ticket': False,
        }
        try:
            log_stream_queue.put_nowait(log_data_for_stream)
        except queue.Full:
            print(f"Warning: Log stream queue is full. Log {log_uuid} from {client_id} will not be streamed live.")
        return jsonify({"status": "logged", "id": log_uuid}), 201
    except IOError as e:
        print(f"Error writing to log file '{LOG_FILE}': {e}")
        return jsonify({"error": "Internal server error writing log"}), 500
    except Exception as e:
        print(f"Unexpected error writing log: {e}")
        return jsonify({"error": "Internal server error"}), 500
@app.route('/analyze')
def analyze_logs():
    logs = read_logs_with_state(filter_deleted=True)
    return render_template('analyzer.html', logs=logs)
@app.route('/api/logs')
def get_all_logs():
    return jsonify(read_logs_with_state(filter_deleted=True))

@app.route('/view', methods=['GET'])
def view_logs():
    initial_logs = read_logs_with_state(filter_deleted=True, filter_tickets=False)
    initial_logs = initial_logs[:200]
    return render_template('view_logs.html', logs=initial_logs)

@app.route('/tickets', methods=['GET'])
def view_tickets():
    tickets = read_logs_with_state(filter_deleted=True, filter_tickets=True)
    return render_template('tickets.html', tickets=tickets)

@app.route('/stream-logs')
def stream_logs():
    def generate_log_messages():
        last_keepalive = datetime.datetime.now()
        try:
            while True:
                try:
                    log_data = log_stream_queue.get(timeout=1)
                    yield f"data: {json.dumps(log_data)}\n\n"
                    log_stream_queue.task_done()
                    last_keepalive = datetime.datetime.now()
                except queue.Empty:
                    if (datetime.datetime.now() - last_keepalive).total_seconds() > 25:
                        yield ": keepalive\n\n"
                        last_keepalive = datetime.datetime.now()
                    continue
        except GeneratorExit:
            pass
    return Response(stream_with_context(generate_log_messages()), mimetype='text/event-stream')

@app.route('/api/logs/new', methods=['GET'])
def get_new_logs():
    since_uuid = request.args.get('since_uuid')
    if not since_uuid:
        return jsonify([])
    all_logs = read_logs_with_state(filter_deleted=True, filter_tickets=False)
    new_logs = []
    for log in all_logs:
        if log['uuid'] == since_uuid:
            break
        new_logs.append(log)
    new_logs.reverse()
    return jsonify(new_logs)

@app.route('/api/logs/<log_uuid>/pin', methods=['POST'])
def pin_log(log_uuid):
    state_data = load_state()
    log_state = state_data.setdefault(log_uuid, {})
    new_status = not log_state.get('pinned', False)
    log_state['pinned'] = new_status
    save_state(state_data)
    return jsonify({"success": True, "id": log_uuid, "is_pinned": new_status}), 200

@app.route('/api/logs/<log_uuid>/ticket', methods=['POST'])
def ticket_log(log_uuid):
    state_data = load_state()
    log_state = state_data.setdefault(log_uuid, {})
    new_status = not log_state.get('ticketed', False)
    log_state['ticketed'] = new_status
    save_state(state_data)
    return jsonify({"success": True, "id": log_uuid, "is_ticket": new_status}), 200

@app.route('/api/logs/<log_uuid>/delete', methods=['POST'])
def delete_log(log_uuid):
    state_data = load_state()
    log_state = state_data.setdefault(log_uuid, {})
    log_state['deleted'] = True
    save_state(state_data)
    return jsonify({"success": True, "id": log_uuid}), 200

@app.route('/api/log_stats', methods=['GET'])
def get_log_stats():
    stats = {level: 0 for level in VALID_LOG_LEVELS}
    logs_for_stats = read_logs_with_state(filter_deleted=True, filter_tickets=False)
    for log in logs_for_stats:
        level = log.get('log_level', 'UNKNOWN')
        if level in stats:
            stats[level] += 1
        else:
            stats['UNKNOWN'] += 1
    return jsonify(stats), 200

@app.route('/api/export_tickets', methods=['GET'])
def export_tickets():
    try:
        ticketed_logs = read_logs_with_state(filter_deleted=True, filter_tickets=True)
        if not ticketed_logs:
            return jsonify({"error": "No ticketed logs found"}), 404
        output = io.StringIO()
        output.write("Ticketed Logs Export\n")
        output.write("=" * 50 + "\n\n")
        for log in ticketed_logs:
            output.write(f"Timestamp: {log['timestamp_str']}\n")
            output.write(f"Level: {log['log_level']}\n")
            output.write(f"Client ID: {log['client_id']}\n")
            output.write(f"UUID: {log['uuid']}\n")
            output.write(f"Message: {log['message']}\n")
            output.write("-" * 50 + "\n")
        output.seek(0)
        buffer = io.BytesIO(output.getvalue().encode('utf-8'))
        buffer.seek(0)
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"ticketed_logs_{timestamp}.txt"
        output.close()
        return send_file(
            buffer,
            mimetype='text/plain',
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        print(f"Error exporting ticketed logs: {e}")
        return jsonify({"error": "Internal server error during export"}), 500

if __name__ == '__main__':
    print(f"Starting logging server...")
    print(f" - Log File: {os.path.abspath(LOG_FILE)}")
    print(f" - State File: {os.path.abspath(STATE_FILE)}")
    print(f" - Log endpoint: http://localhost:5000/log (POST)")
    print(f" - View endpoint: http://localhost:5000/view (GET)")
    print(f" - Tickets endpoint: http://localhost:5000/tickets (GET)")
    print(f" - New Logs API (polling): /api/logs/new?since_uuid=<uuid>")
    print(f" - Live Log Stream (SSE): http://localhost:5000/stream-logs (GET)")
    import os
    debug_mode = os.environ.get('FLASK_ENV') == 'development' or os.environ.get('DEBUGPY')
    app.run(host='0.0.0.0', port=5000, debug=debug_mode, use_reloader=not debug_mode)
